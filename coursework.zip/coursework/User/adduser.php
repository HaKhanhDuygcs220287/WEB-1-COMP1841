<?php
if(isset($_POST['name']) && isset($_POST['email'])){
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DataBaseFunctions.php';

        addUser($pdo, $_POST['name'], $_POST['email']);

        // Chuyển hướng đến addpost.php để cập nhật danh sách user
        header('location: addpost.php');
        exit();
    }catch (PDOException $e){
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    }
}else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DataBaseFunctions.php';
    
    $title = 'Add a new user';

    // Lấy danh sách user mới nhất
    $users = allusers($pdo);

    ob_start();
    include '../templates/adduser.html.php';
    $output = ob_get_clean();
}
include '../templates/user_layout.html.php';
