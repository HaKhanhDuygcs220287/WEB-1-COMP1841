<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

if (!isset($_GET['id'])) {
    header('Location: managemodule.php');
    exit();
}

try {
    // Lấy thông tin module cần chỉnh sửa
    $module = getModuleById($pdo, $_GET['id']); 
    
    if (!$module) {
        die('Module not found.');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['moduleName'])) {
        updateModule($pdo, $_GET['id'], $_POST['moduleName']);
        header('Location: managemodule.php');
        exit();
    }

    $title = 'Edit Module';
    ob_start();
    include '../templates/editmodule.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'Error';
    $output = 'Database error: ' . $e->getMessage();
}

include '../templates/user_layout.html.php';
