<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

try {
    
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        throw new Exception("wrong id.");
    }

    $id = intval($_GET['id']);

    // Kiểm tra xem người dùng có tồn tại không trước khi xóa
    $user = getUser($pdo, $id);
    if (!$user) {
        throw new Exception("not user found.");
    }

    // Xóa người dùng
    deleteUser($pdo, $id);

    // Quay về danh sách người dùng
    header('location: manageuser.php');
    exit;
} catch (Exception $e) {
    $title = 'Error';
    $output = '<p style="color:red;">Lỗi: ' . htmlspecialchars($e->getMessage()) . '</p>';
}

include '../templates/user_layout.html.php';
?>
