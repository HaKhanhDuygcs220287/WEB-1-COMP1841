<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['moduleName'])) {
    try {
        if (!empty($_POST['id'])) {
            updateModule($pdo, $_POST['id'], $_POST['moduleName']);  // Sửa module
        } else {
            addModule($pdo, $_POST['moduleName']);  // Thêm module mới
        }
        header('Location: managemodule.php');
        exit();
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
}

try {
    $modules = allModules($pdo);
    $title = 'Module Management';
    ob_start();
    include '../templates/managemodule.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'Error';
    $output = 'Error fetching modules: ' . $e->getMessage();
}

include '../templates/user_layout.html.php';
