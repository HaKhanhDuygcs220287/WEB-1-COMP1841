<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

try {
    if (isset($_POST['name'])) {
        updateUser($pdo, $_POST['id'], $_POST['name'], $_POST['email']);

        header('location: manageuser.php'); // Chuyển hướng về danh sách người dùng
        exit;
    } else {
        // Lấy thông tin người dùng cần chỉnh sửa
        $user = getuser($pdo, $_GET['id']);

        $title = 'Edit User';
        ob_start();
        include '../templates/edituser.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'Error';
    $output = 'Error editing user: ' . $e->getMessage();
}

include '../templates/user_layout.html.php';
?>
