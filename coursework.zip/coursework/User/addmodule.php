<?php
if(isset($_POST['modulename'])){
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DataBaseFunctions.php';

        addmodule($pdo, $_POST['modulename'], );

        // Chuyển hướng đến addpost.php để cập nhật danh sách user
        header('location: addpost.php');
        exit();
    }catch (PDOException $e){
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    }
}else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DataBaseFunctions.php';
    
    $title = 'Add a new module';

    // Lấy danh sách user mới nhất
    $users = allmodules($pdo);

    ob_start();
    include '../templates/addmodule.html.php';
    $output = ob_get_clean();
}
include '../templates/user_layout.html.php';