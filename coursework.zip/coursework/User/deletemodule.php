<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

if (isset($_GET['id'])) {
    try {
        deleteModule($pdo, $_GET['id']);
        header('Location: managemodule.php');
        exit();
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
} else {
    header('Location: managemodule.php');
    exit();
}
