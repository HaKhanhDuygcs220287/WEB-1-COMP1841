<?php
include '../includes/DatabaseConnection.php';
include '../includes/DataBaseFunctions.php';

try {
    // Lấy danh sách người dùng từ database
    $users = allUsers($pdo); 

    $title = 'User List';
    ob_start();
    include '../templates/manageuser.html.php'; 
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'Error';
    $output = 'Error fetching users: ' . $e->getMessage();
}

include '../templates/user_layout.html.php';
?>
