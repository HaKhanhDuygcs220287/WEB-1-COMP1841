<?php
$title = "View Sent Messages";
$messages = file('../data/messages.txt', FILE_IGNORE_NEW_LINES);

ob_start();
?>
<ul>
    <?php foreach ($messages as $msg): ?>
        <li><?php echo htmlspecialchars($msg); ?></li>
    <?php endforeach; ?>
</ul>
<?php
$output = ob_get_clean();
include '../templates/admin_layout.html.php';
