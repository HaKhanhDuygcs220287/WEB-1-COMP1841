<?php
function query($pdo, $sql,$parameters = []){
    $query = $pdo->prepare($sql);
    $query ->execute($parameters);
    return $query;
}
function totalposts($pdo){
    $query = query($pdo,'SELECT COUNT(*) FROM post');
    $row = $query->fetch();
    return $row[0];
}
function getpost($pdo, $id) {
    $parameters = [':id' => $id];
    $query = query($pdo,'SELECT * FROM post WHERE id = :id',$parameters);
    return $query->fetch();
}
function updatepost($pdo, $postid, $posttext){
    $query = 'UPDATE post SET posttext =:posttext WHERE id = :id';
    $parameters = [':posttext' => $posttext, ':id' => $postid];
    query($pdo, $query, $parameters);
}
function deletepost($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo,'DELETE FROM post WHERE id = :id',$parameters);
}
function insertpost($pdo, $posttext, $fileToUpload, $userid, $moduleid) {
    $query = 'INSERT INTO post (posttext, postdate, post_pic, userid, moduleid)
    VALUES(:posttext, CURDATE(), :fileToUpload, :userid, :moduleid)';
    $parameters = [':posttext' => $posttext, ':fileToUpload' =>$fileToUpload, ':userid' => $userid, ':moduleid' => $moduleid];
    query($pdo, $query, $parameters);
}
function allusers($pdo) {
    $users = query($pdo ,'SELECT * FROM user');
    return $users -> fetchALL();
}
function allmodules($pdo) {
    $modules = query($pdo, 'SELECT * FROM module');
    return $modules->fetchALL();
}
function allposts($pdo){
    $posts = query($pdo,'SELECT post.id,post_pic, posttext, postdate, `name`, email, moduleName FROM post
    INNER JOIN user ON userid = user.id
    INNER JOIN module ON moduleid = module.id');
    return $posts->fetchAll();
}
function updateUserAndModule($pdo, $postid, $userid, $moduleid) {
    $query = 'UPDATE post SET userid = :userid, moduleid = :moduleid WHERE id = :id';
    $parameters = [':userid' => $userid, ':moduleid' => $moduleid, ':id' => $postid];
    query($pdo, $query, $parameters);
}

function addUser($pdo, $name, $email) {
    $sql = 'INSERT INTO user (name, email) VALUES (:name, :email)';
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':email', $email);
    $stmt->execute();
}
function updateUser($pdo, $id, $name, $email) {
    $sql = "UPDATE user SET name = :name, email = :email WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['name' => $name, 'email' => $email, 'id' => $id]);
}

function getuser($pdo, $id) {
    $sql = "SELECT * FROM user WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    return $user ?: null; 
}

function deleteUser($pdo, $id) {
    $sql = "DELETE FROM user WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
}

function addModule($pdo, $moduleName) {
    $sql = "INSERT INTO module (moduleName) VALUES (:moduleName)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['moduleName' => $moduleName]);
}

function updateModule($pdo, $id, $moduleName) {
    $sql = "UPDATE module SET moduleName = :moduleName WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['moduleName' => $moduleName, 'id' => $id]);
}

function deleteModule($pdo, $id) {
    try {
        $sql1 = "DELETE FROM post WHERE moduleid = :id";
        $stmt1 = $pdo->prepare($sql1);
        $stmt1->execute(['id' => $id]);

        $sql2 = "DELETE FROM module WHERE id = :id";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->execute(['id' => $id]);

        return true;
    } catch (PDOException $e) {
        return false;
    }
}


function getModuleById($pdo, $id) {
    $sql = "SELECT * FROM module WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}



