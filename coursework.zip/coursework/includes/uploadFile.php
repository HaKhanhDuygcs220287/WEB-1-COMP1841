<?php
$tarket_dir ="uploads/";
$target_file = $target_dir . basename($FILES["fileToUpload"] ["name"]);