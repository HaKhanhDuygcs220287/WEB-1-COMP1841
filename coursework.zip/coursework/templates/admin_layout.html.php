<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../adminposts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header id="user">
        <h1>Admin Home Page <br/>
    Admin Place</h1></header>
        <nav>
            <ul>
                <!-- <li><a href="index.php">Home</a></li> -->
                <li><a href="posts.php">View</a></li>
                <li><a href="addpost.php">Add New</a></li>
                <li><a href="Login/logout.html">Logout</a></li>
                <li><a href="view_contact_send.php">View Sent Messages</a></li>
                <!--<li><a href="contact.php">Contact Us</a></li>-->

            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>
