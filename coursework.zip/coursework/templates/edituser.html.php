<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Edit</title>
</head>
<body>
    <h2>Edit</h2>
    <form action="edituser.php" method="post">
        <input type="hidden" name="id" value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8') ?>">

        <label for="name">name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?>" required>
        <br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?>" required>
        <br>

        <button type="submit">submit</button>
    </form>
    <br>
    <a href="manageuser.php">Quay lại danh sách</a>
</body>
</html>
