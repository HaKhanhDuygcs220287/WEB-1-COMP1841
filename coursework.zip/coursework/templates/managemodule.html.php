<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <h1>Module Management</h1>

    <!-- Form thêm / chỉnh sửa module -->
    <form action="managemodule.php" method="post">
        <input type="hidden" id="id" name="id">
        
        <label for="moduleName">Module Name:</label>
        <input type="text" id="moduleName" name="moduleName" required>

        <button type="submit">Save Module</button>
        <button type="button" id="cancelEdit" style="display: none;">Cancel</button>
    </form>

    <h2>Module List</h2>
    
    <?php if (!empty($modules)): ?>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Module Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($modules as $module): ?>
            <tr>
                <td><?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <button onclick="editModule('<?= $module['id'] ?>', '<?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8') ?>')">Edit</button>
                    <a href="deletemodule.php?id=<?= urlencode($module['id']) ?>" onclick="return confirm('Are you sure you want to delete this module?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No modules found.</p>
    <?php endif; ?>

    <script>
        function editModule(id, name) {
            document.getElementById('id').value = id;
            document.getElementById('moduleName').value = name;
            document.querySelector('button[type="submit"]').textContent = "Update Module";
            document.getElementById('cancelEdit').style.display = "inline";
        }

        document.getElementById('cancelEdit').addEventListener('click', function() {
            document.getElementById('id').value = "";
            document.getElementById('moduleName').value = "";
            document.querySelector('button[type="submit"]').textContent = "Save Module";
            this.style.display = "none";
        });
    </script>
</body>
</html>
