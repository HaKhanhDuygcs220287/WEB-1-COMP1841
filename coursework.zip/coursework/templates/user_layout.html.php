<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../userposts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header id="user">
        <h1>User Home Page <br/>
        Place For User</h1></header>
        <nav>
            <ul>
                <!-- <li><a href="index.php">Home</a></li> -->
                <li><a href="posts.php">View</a></li>
                <li><a href="addpost.php">Add New</a></li>
                <li><a href="Login/logout.html">Logout</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="adduser.php">Add User</a></li>
                <li><a href="addmodule.php">Add module</a></li>
                <li><a href="manageuser.php">manageuser</a></li>
                <li><a href="managemodule.php">managemodule</a></li>
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>