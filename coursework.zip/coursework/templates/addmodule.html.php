<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <h1>Module Management</h1>

    <!-- Form thêm / chỉnh sửa module -->
    <form action="managemodule.php" method="post">
        <input type="hidden" id="id" name="id">
        
        <label for="moduleName">Module Name:</label>
        <input type="text" id="moduleName" name="moduleName" required>

        <button type="submit">Save Module</button>
        <button type="button" id="cancelEdit" style="display: none;">Cancel</button>
    </form>