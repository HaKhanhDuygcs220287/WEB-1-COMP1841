<form action="" method="post">
    <label for="message">Your Message:</label>
    <textarea id="message" name="message" required></textarea>
    <button type="submit">Send</button>
</form>