<form action="" method="post">
    <p> Type your question here </P>
    <textarea name="message" rows="15" cols="40"></textarea><br />
    <input type="submit" value="send email">
</form>